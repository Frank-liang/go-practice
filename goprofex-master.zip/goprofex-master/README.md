Profiling and optimizing Go web applications: Example
=====================================================

Example showing how to profile and optimize Go web applications.

The initial version is tagged as [v1](https://github.com/akrylysov/goprofex/tree/v1) and the optimized version is tagged as [v2](https://github.com/akrylysov/goprofex/tree/v2).
Here is [the link](https://github.com/akrylysov/goprofex/compare/v1...v2) to compare these two versions.

You can find more details at <http://artem.krylysov.com/blog/2017/03/13/profiling-and-optimizing-go-web-applications/>.

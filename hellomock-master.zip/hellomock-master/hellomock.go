package hellomock

type Talker interface{
	SayHello(workd string) string
}
